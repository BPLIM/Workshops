<meta charset="utf-8"/>
# Central Credit Responsibility Database
## Codebook
`extraction`: May 2018


{{1}}

